const exportButton = document.getElementById("exportButton");
const statusBox = document.getElementById("status");

function getMessage(key, substitutions) {
  return chrome.i18n.getMessage(key, substitutions) || key;
}

function localizePopup() {
  const uiLanguage = String(chrome.i18n.getUILanguage() || "en").toLowerCase();
  document.documentElement.lang = uiLanguage.startsWith("ja") ? "ja" : "en";

  document.querySelectorAll("[data-i18n]").forEach((element) => {
    const message = getMessage(element.dataset.i18n);
    if (element.tagName === "TITLE") {
      document.title = message;
    } else {
      element.textContent = message;
    }
  });

  document.querySelectorAll("[data-i18n-aria-label]").forEach((element) => {
    element.setAttribute("aria-label", getMessage(element.dataset.i18nAriaLabel));
  });
}

localizePopup();

const WORK_REPORT_PREFIXES = [
  "作成しました",
  "変更しました",
  "修正しました",
  "追加しました",
  "実装しました",
  "確認しました",
  "確認結果",
  "変更内容",
  "実装内容",
  "作成場所",
  "作成ファイル",
  "変更ファイル",
  "追加ファイル",
  "確認事項"
];

const WORK_REPORT_PATTERNS = [
  /^(作成|変更|修正|追加|実装|確認)しました[。.]?$/,
  /^(作成|変更|修正|追加|実装|確認)しました[。.]?\n/,
  /^(確認結果|変更内容|実装内容|作成場所|作成ファイル|変更ファイル|追加ファイル|確認事項)[:：]?/
];

function setStatus(message, type = "") {
  statusBox.textContent = message;
  statusBox.className = type;
}

function normalizeForCheck(text) {
  return String(text || "")
    .replace(/\s+/g, "")
    .trim();
}

function isWorkReportText(text) {
  const normalized = String(text || "").trim();
  const compact = normalizeForCheck(text);

  if (WORK_REPORT_PREFIXES.some((prefix) => normalized.startsWith(prefix) || compact.startsWith(prefix))) {
    return true;
  }

  return WORK_REPORT_PATTERNS.some((pattern) => pattern.test(normalized) || pattern.test(compact));
}

function isAssistantMessage(message) {
  return message && (message.role === "ASSISTANT" || message.role === "AI");
}

function extractUserMessagesWithAssistantContext(messages) {
  const results = [];
  let previousAssistant = null;

  (messages || []).forEach((message) => {
    if (isAssistantMessage(message)) {
      previousAssistant = message;
      return;
    }

    if (message.role !== "USER" || isWorkReportText(message.text)) {
      return;
    }

    if (previousAssistant && previousAssistant.text) {
      results.push({
        role: "ASSISTANT",
        text: previousAssistant.text
      });
    }

    results.push({
      role: "USER",
      text: message.text
    });
  });

  return results;
}

function buildTextExport(payload, messages) {
  const lines = [];
  lines.push(payload.provider === "chatgpt" ? "ChatGPT Conversation Log" : "AI Conversation Log");
  lines.push("Extraction Rule: user messages with previous assistant context");
  lines.push(`Title: ${payload.title || "Untitled"}`);
  lines.push(`URL: ${payload.url || ""}`);
  lines.push(`Copied At: ${new Date().toLocaleString()}`);
  lines.push("");

  messages.forEach((message, index) => {
    lines.push(`--- ${index + 1}. ${message.role} ---`);
    lines.push(message.text);
    lines.push("");
  });

  return lines.join("\n");
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0];
}

function sendExtractMessage(tabId) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, { type: "EXTRACT_AI_LOG" }, (response) => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      resolve(response);
    });
  });
}

async function ensureContentScript(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["content.js"]
  });
}

async function extractFromTab(tabId) {
  try {
    return await sendExtractMessage(tabId);
  } catch (_error) {
    // Existing chat tabs may not have the latest content script until the page is refreshed.
    await ensureContentScript(tabId);
    return sendExtractMessage(tabId);
  }
}

async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    return;
  } catch (_error) {
    // Extension popups can reject Clipboard API depending on focus/permission state.
  }

  const textarea = document.createElement("textarea");
  textarea.value = text;
  textarea.setAttribute("readonly", "");
  textarea.style.position = "fixed";
  textarea.style.left = "-9999px";
  textarea.style.top = "0";
  document.body.appendChild(textarea);
  textarea.focus();
  textarea.select();

  const copied = document.execCommand("copy");
  document.body.removeChild(textarea);

  if (!copied) {
    throw new Error(getMessage("clipboardCopyFailed"));
  }
}

exportButton.addEventListener("click", async () => {
  exportButton.disabled = true;
  setStatus(getMessage("extractingStatus"));

  try {
    const tab = await getActiveTab();
    const isSupportedSite = Boolean(
      tab?.url && (
        tab.url.startsWith("https://chatgpt.com/") ||
        tab.url.startsWith("https://claude.ai/") ||
        tab.url.startsWith("https://gemini.google.com/")
      )
    );
    if (!tab || !tab.id || !isSupportedSite) {
      throw new Error(getMessage("unsupportedPage"));
    }

    const response = await extractFromTab(tab.id);
    if (!response || !response.ok) {
      throw new Error(response?.error || getMessage("extractionFailed"));
    }

    const messages = extractUserMessagesWithAssistantContext(response.messages || []);
    if (!messages.length) {
      throw new Error(getMessage("noUserMessages"));
    }

    const text = buildTextExport(response, messages);
    await copyToClipboard(text);

    setStatus(
      `${getMessage("successTitle")}\n\n${getMessage("successInstruction")}`,
      "success"
    );
  } catch (error) {
    const detail = String(error?.message || "").trim();
    setStatus(
      detail.startsWith(getMessage("extractionFailed"))
        ? detail
        : `${getMessage("extractionFailed")}${detail ? `\n${detail}` : ""}`,
      "error"
    );
  } finally {
    exportButton.disabled = false;
  }
});

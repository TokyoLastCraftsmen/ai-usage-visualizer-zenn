(function () {
  const ROLE_LABELS = {
    user: "USER",
    assistant: "AI"
  };

  function normalizeText(text) {
    return String(text || "")
      .replace(/\u00a0/g, " ")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  }

  function getElementText(element) {
    const clone = element.cloneNode(true);
    clone.querySelectorAll("button, svg, style, script, noscript").forEach((node) => node.remove());
    return normalizeText(clone.innerText || clone.textContent || "");
  }

  function findMessageByDataAttributes() {
    const nodes = Array.from(document.querySelectorAll('[data-message-author-role]'));
    return nodes
      .map((node) => {
        const role = node.getAttribute("data-message-author-role");
        return {
          role: ROLE_LABELS[role] || role || "UNKNOWN",
          text: getElementText(node),
          source: "data-message-author-role"
        };
      })
      .filter((item) => item.text);
  }

  function findMessageByArticleElements() {
    const articles = Array.from(document.querySelectorAll("main article, article"));
    return articles
      .map((article) => {
        const text = getElementText(article);
        if (!text) {
          return null;
        }

        const ariaLabel = `${article.getAttribute("aria-label") || ""} ${article.textContent || ""}`.toLowerCase();
        let role = "UNKNOWN";
        if (ariaLabel.includes("you") || ariaLabel.includes("user") || ariaLabel.includes("あなた")) {
          role = "USER";
        } else if (ariaLabel.includes("chatgpt") || ariaLabel.includes("assistant") || ariaLabel.includes("アシスタント")) {
          role = "AI";
        }

        return { role, text, source: "article" };
      })
      .filter(Boolean);
  }

  function findMessageByConversationTurns() {
    const selectors = [
      '[data-testid^="conversation-turn"]',
      '[class*="group/conversation-turn"]',
      ".group.w-full"
    ];

    const nodes = Array.from(document.querySelectorAll(selectors.join(",")));
    return nodes
      .map((node) => {
        const text = getElementText(node);
        if (!text) {
          return null;
        }

        const raw = node.outerHTML.toLowerCase();
        let role = "UNKNOWN";
        if (raw.includes('data-message-author-role="user"')) {
          role = "USER";
        } else if (raw.includes('data-message-author-role="assistant"')) {
          role = "AI";
        } else if (raw.includes("chatgpt")) {
          role = "AI";
        }

        return { role, text, source: "conversation-turn" };
      })
      .filter(Boolean);
  }

  function getProvider() {
    const hostname = String(location.hostname || "").toLowerCase();
    if (hostname === "gemini.google.com" || hostname.endsWith(".gemini.google.com")) {
      return "gemini";
    }
    if (hostname === "claude.ai" || hostname.endsWith(".claude.ai")) {
      return "claude";
    }
    if (hostname === "chatgpt.com" || hostname.endsWith(".chatgpt.com")) {
      return "chatgpt";
    }
    return "unknown";
  }

  function getClaudeRole(node) {
    const testId = String(node.getAttribute("data-testid") || "").toLowerCase();
    const ariaLabel = String(node.getAttribute("aria-label") || "").toLowerCase();
    const className = String(node.className || "").toLowerCase();
    const context = `${testId} ${ariaLabel} ${className}`;

    if (context.includes("user") || context.includes("human")) {
      return "USER";
    }
    if (
      context.includes("assistant") ||
      context.includes("claude") ||
      context.includes("font-claude-response")
    ) {
      return "AI";
    }

    const parent = node.closest(
      '[data-testid*="user"], [data-testid*="human"], [data-testid*="assistant"], [data-testid*="claude"]'
    );
    if (parent && parent !== node) {
      return getClaudeRole(parent);
    }
    return "UNKNOWN";
  }

  const CLAUDE_ASSISTANT_BODY_SELECTOR = [
    ".font-claude-response",
    '[data-testid="assistant-response-content"]',
    '[data-testid="message-content"] .prose'
  ].join(",");

  const CLAUDE_ASSISTANT_CONTENT_SELECTORS = [
    '[data-testid="markdown-content"]',
    ".standard-markdown",
    ".prose"
  ];

  const CLAUDE_ASSISTANT_BLOCK_SELECTOR = [
    "p",
    "pre",
    "blockquote",
    "table",
    "ul",
    "ol",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6"
  ].join(",");

  const CLAUDE_EXCLUDED_TEXT_SELECTOR = [
    "button",
    "svg",
    "style",
    "script",
    "noscript",
    "[hidden]",
    "[inert]",
    '[aria-hidden="true"]',
    "[aria-live]",
    '[role="status"]',
    "details",
    "summary",
    '[data-testid*="summary"]',
    '[data-testid*="thinking"]',
    '[data-testid*="thought"]',
    '[data-testid*="reasoning"]',
    '[data-testid*="screen-reader"]',
    ".sr-only",
    '[class*="sr-only"]',
    '[class*="visually-hidden"]',
    '[class*="screen-reader"]',
    '[class*="thinking"]',
    '[class*="thought"]',
    '[class*="reasoning"]'
  ].join(",");

  function isClaudeAuxiliaryElement(element) {
    if (!element) {
      return true;
    }

    if (element.matches(CLAUDE_EXCLUDED_TEXT_SELECTOR)) {
      return true;
    }

    const auxiliaryParent = element.closest(CLAUDE_EXCLUDED_TEXT_SELECTOR);
    if (auxiliaryParent && auxiliaryParent !== element) {
      return true;
    }

    const text = normalizeText(element.innerText || "");
    return /(?:\d+\s*秒間思考しました|thought for \d+\s*seconds?)/i.test(text);
  }

  function getClaudeVisibleText(element) {
    if (!element) {
      return "";
    }

    const excludedNodes = element.querySelectorAll(CLAUDE_EXCLUDED_TEXT_SELECTOR);
    if (excludedNodes.length === 0) {
      return normalizeText(element.innerText || element.textContent || "");
    }

    const clone = element.cloneNode(true);
    clone.querySelectorAll(CLAUDE_EXCLUDED_TEXT_SELECTOR).forEach((node) => node.remove());
    return normalizeText(clone.textContent || "");
  }

  function getClaudeAssistantText(responseRoot) {
    if (!responseRoot) {
      return "";
    }

    let contentNodes = [];
    for (const selector of CLAUDE_ASSISTANT_CONTENT_SELECTORS) {
      contentNodes = Array.from(responseRoot.querySelectorAll(selector))
        .filter((node) => !isClaudeAuxiliaryElement(node));
      if (contentNodes.length > 0) {
        break;
      }
    }

    if (contentNodes.length === 0) {
      const blockNodes = Array.from(responseRoot.querySelectorAll(CLAUDE_ASSISTANT_BLOCK_SELECTOR))
        .filter((node) => !isClaudeAuxiliaryElement(node));
      contentNodes = blockNodes.filter(
        (node) => !blockNodes.some((other) => other !== node && other.contains(node))
      );
    }

    const seen = new Set();
    return contentNodes
      .map((node) => getClaudeVisibleText(node))
      .filter((text) => {
        if (!text || seen.has(text)) {
          return false;
        }
        seen.add(text);
        return true;
      })
      .join("\n\n");
  }

  function findClaudeMessageBody(node, role) {
    if (role === "USER") {
      if (node.matches('[data-testid="user-message"]')) {
        return node;
      }
      return node.querySelector('[data-testid="user-message"]');
    }

    if (role === "AI") {
      if (node.matches(CLAUDE_ASSISTANT_BODY_SELECTOR)) {
        return node;
      }
      return node.querySelector(CLAUDE_ASSISTANT_BODY_SELECTOR);
    }

    return null;
  }

  function findClaudeMessagesByKnownSelectors() {
    const selectors = [
      '[data-testid="user-message"]',
      ".font-claude-response",
      '[data-testid="assistant-response-content"]'
    ];
    const scopedSelectors = selectors.map((selector) => `main ${selector}`);
    let nodes = Array.from(document.querySelectorAll(scopedSelectors.join(",")));
    if (nodes.length === 0) {
      nodes = Array.from(document.querySelectorAll(selectors.join(",")));
    }

    return nodes
      .map((node) => {
        const role = getClaudeRole(node);
        const body = findClaudeMessageBody(node, role);
        const text = role === "AI"
          ? getClaudeAssistantText(body)
          : getClaudeVisibleText(body);
        if (!text) {
          return null;
        }
        return {
          role,
          text,
          source: "claude-known-selector"
        };
      })
      .filter(Boolean);
  }

  function findClaudeMessagesByConversationTurns() {
    const selectors = [
      'main [data-testid^="conversation-turn"]',
      'main [data-testid*="chat-message"]',
      'main [data-testid*="message-row"]'
    ];
    const nodes = Array.from(document.querySelectorAll(selectors.join(",")));

    return nodes
      .map((node) => {
        const role = getClaudeRole(node);
        const body = findClaudeMessageBody(node, role);
        const text = role === "AI"
          ? getClaudeAssistantText(body)
          : getClaudeVisibleText(body);
        if (!text) {
          return null;
        }
        return {
          role,
          text,
          source: "claude-conversation-turn"
        };
      })
      .filter(Boolean);
  }

  const GEMINI_EXCLUDED_TEXT_SELECTOR = [
    "button",
    "svg",
    "style",
    "script",
    "noscript",
    "[hidden]",
    "[inert]",
    '[aria-hidden="true"]',
    "[aria-live]",
    '[role="status"]',
    "details",
    "summary",
    "mat-chip",
    "gem-icon-button",
    "gem-icon",
    "mat-icon",
    "thumb-up-button",
    "thumb-down-button",
    "regenerate-button",
    "copy-button",
    "message-actions",
    "sources-list",
    "link-block",
    "thinking-overlay",
    "sensitive-memories-banner",
    '[data-test-id*="citation"]',
    '[data-test-id*="source"]',
    '[data-test-id*="grounding"]',
    '[data-test-id*="related"]',
    '[data-test-id*="suggestion"]',
    '[data-test-id*="feedback"]',
    '[data-test-id*="share"]',
    '[data-test-id*="loading"]',
    '[data-testid*="citation"]',
    '[data-testid*="source"]',
    '[data-testid*="related"]',
    '[data-testid*="feedback"]',
    '[class*="citation"]',
    '[class*="source-card"]',
    '[class*="search-result"]',
    '[class*="related"]',
    '[class*="suggestion"]',
    '[class*="chip"]',
    '[class*="feedback"]',
    '[class*="share"]',
    '[class*="disclaimer"]',
    '[class*="loading"]',
    '[class*="sr-only"]',
    '[class*="visually-hidden"]',
    '[class*="screen-reader"]'
  ].join(",");

  const GEMINI_DIRECT_EXCLUDED_TEXT_SELECTOR = [
    "button",
    "svg",
    "style",
    "script",
    "noscript",
    "[hidden]",
    "[inert]",
    '[aria-hidden="true"]',
    "details",
    "summary",
    "mat-chip",
    "gem-icon-button",
    "gem-icon",
    "mat-icon",
    "thumb-up-button",
    "thumb-down-button",
    "regenerate-button",
    "copy-button",
    "message-actions",
    "sources-list",
    "link-block",
    "thinking-overlay",
    "sensitive-memories-banner",
    '[data-test-id*="citation"]',
    '[data-test-id*="source"]',
    '[data-test-id*="grounding"]',
    '[data-test-id*="related"]',
    '[data-test-id*="suggestion"]',
    '[data-test-id*="feedback"]',
    '[data-test-id*="share"]',
    '[data-test-id*="loading"]',
    '[data-testid*="citation"]',
    '[data-testid*="source"]',
    '[data-testid*="related"]',
    '[data-testid*="feedback"]',
    '[class*="citation"]',
    '[class*="source-card"]',
    '[class*="search-result"]',
    '[class*="related"]',
    '[class*="suggestion"]',
    '[class*="chip"]',
    '[class*="feedback"]',
    '[class*="share"]',
    '[class*="disclaimer"]',
    '[class*="loading"]',
    '[class*="sr-only"]',
    '[class*="visually-hidden"]',
    '[class*="screen-reader"]'
  ].join(",");

  const GEMINI_DIRECT_ROOT_EXCLUDED_SELECTOR = [
    "[hidden]",
    "[inert]",
    '[aria-hidden="true"]',
    '[class*="sr-only"]',
    '[class*="visually-hidden"]',
    '[class*="screen-reader"]'
  ].join(",");

  const GEMINI_ASSISTANT_CONTENT_SELECTORS = [
    ".markdown-main-panel",
    '[data-test-id="model-response-text"]',
    '[data-testid="model-response-text"]',
    "message-content",
    "structured-content-container > div.container",
    ".response-container",
    ".model-response-text",
    ".response-content",
    ".markdown",
    ".prose",
    '[class*="markdown"]',
    '[class*="prose"]'
  ];

  const GEMINI_USER_CONTENT_SELECTORS = [
    ".query-text",
    ".query-text-line",
    '[data-test-id="user-query-text"]',
    '[data-testid="user-query-text"]'
  ];

  const GEMINI_TEXT_BLOCK_SELECTOR = [
    "p",
    "pre",
    "blockquote",
    "table",
    "ul",
    "ol",
    "h1",
    "h2",
    "h3",
    "h4",
    "h5",
    "h6"
  ].join(",");

  function getGeminiRole(node) {
    const tagName = String(node.tagName || "").toLowerCase();
    const testId = String(
      node.getAttribute("data-test-id") || node.getAttribute("data-testid") || ""
    ).toLowerCase();
    const className = String(node.className || "").toLowerCase();
    const context = `${tagName} ${testId} ${className}`;

    if (context.includes("user-query") || context.includes("user-message")) {
      return "USER";
    }
    if (context.includes("model-response") || context.includes("assistant-message")) {
      return "AI";
    }

    const parent = node.closest(
      'user-query, model-response, [data-test-id*="user-query"], [data-test-id*="model-response"], [data-testid*="user-query"], [data-testid*="model-response"]'
    );
    if (parent && parent !== node) {
      return getGeminiRole(parent);
    }
    return "UNKNOWN";
  }

  function queryGeminiAll(selector, root = document) {
    const directMatches = Array.from(root.querySelectorAll(selector));
    if (directMatches.length > 0 || root !== document) {
      return directMatches;
    }

    const shadowMatches = [];
    const pendingRoots = Array.from(document.querySelectorAll("*"))
      .map((element) => element.shadowRoot)
      .filter(Boolean);

    while (pendingRoots.length > 0) {
      const shadowRoot = pendingRoots.shift();
      shadowMatches.push(...Array.from(shadowRoot.querySelectorAll(selector)));
      Array.from(shadowRoot.querySelectorAll("*"))
        .map((element) => element.shadowRoot)
        .filter(Boolean)
        .forEach((nestedRoot) => pendingRoots.push(nestedRoot));
    }

    return shadowMatches;
  }

  function queryGeminiIncludingShadowRoots(selector) {
    const matches = Array.from(document.querySelectorAll(selector));
    const pendingRoots = Array.from(document.querySelectorAll("*"))
      .map((element) => element.shadowRoot)
      .filter(Boolean);

    while (pendingRoots.length > 0) {
      const shadowRoot = pendingRoots.shift();
      matches.push(...Array.from(shadowRoot.querySelectorAll(selector)));
      Array.from(shadowRoot.querySelectorAll("*"))
        .map((element) => element.shadowRoot)
        .filter(Boolean)
        .forEach((nestedRoot) => pendingRoots.push(nestedRoot));
    }

    return Array.from(new Set(matches));
  }

  function queryGeminiWithinOpenRoots(root, selector) {
    const matches = Array.from(root.querySelectorAll(selector));
    const pendingRoots = Array.from(root.querySelectorAll("*"))
      .map((element) => element.shadowRoot)
      .filter(Boolean);
    if (root.shadowRoot) {
      pendingRoots.unshift(root.shadowRoot);
    }

    while (pendingRoots.length > 0) {
      const shadowRoot = pendingRoots.shift();
      matches.push(...Array.from(shadowRoot.querySelectorAll(selector)));
      Array.from(shadowRoot.querySelectorAll("*"))
        .map((element) => element.shadowRoot)
        .filter(Boolean)
        .forEach((nestedRoot) => pendingRoots.push(nestedRoot));
    }

    return Array.from(new Set(matches));
  }

  function getGeminiOpenShadowRootChildren(root) {
    const children = [];
    const pendingElements = [root, ...Array.from(root.querySelectorAll("*"))];

    while (pendingElements.length > 0) {
      const element = pendingElements.shift();
      if (!element.shadowRoot) {
        continue;
      }
      const shadowChildren = Array.from(element.shadowRoot.children || []);
      children.push(...shadowChildren);
      pendingElements.push(...Array.from(element.shadowRoot.querySelectorAll("*")));
    }

    return children;
  }

  function isGeminiDirectRootExcluded(node) {
    if (!node) {
      return true;
    }
    return Boolean(node.closest(GEMINI_DIRECT_ROOT_EXCLUDED_SELECTOR));
  }

  function getGeminiDirectCleanText(node) {
    if (!node || node.matches(GEMINI_DIRECT_EXCLUDED_TEXT_SELECTOR)) {
      return "";
    }

    const clone = node.cloneNode(true);
    clone.querySelectorAll(GEMINI_DIRECT_EXCLUDED_TEXT_SELECTOR)
      .forEach((excludedNode) => excludedNode.remove());
    return normalizeText(clone.innerText || clone.textContent || "");
  }

  function getGeminiDirectTextFromNodes(nodes) {
    const seen = new Set();
    return nodes
      .map((node) => getGeminiDirectCleanText(node))
      .filter((text) => {
        if (!text || seen.has(text)) {
          return false;
        }
        seen.add(text);
        return true;
      })
      .join("\n\n");
  }

  function getGeminiDirectMessageText(root, role) {
    const roleSelectors = role === "USER"
      ? GEMINI_USER_CONTENT_SELECTORS
      : GEMINI_ASSISTANT_CONTENT_SELECTORS;
    for (const selector of roleSelectors) {
      const text = getGeminiDirectTextFromNodes(
        queryGeminiWithinOpenRoots(root, selector)
      );
      if (text) {
        return text;
      }
    }

    const blockText = getGeminiDirectTextFromNodes(
      queryGeminiWithinOpenRoots(root, GEMINI_TEXT_BLOCK_SELECTOR)
    );
    if (blockText) {
      return blockText;
    }

    return getGeminiDirectTextFromNodes([
      root,
      ...getGeminiOpenShadowRootChildren(root)
    ]);
  }

  function findGeminiMessagesByDirectTags() {
    const nodes = queryGeminiIncludingShadowRoots("user-query, model-response");
    const messages = [];

    nodes.forEach((node) => {
      const tagName = String(node.tagName || "").toLowerCase();
      const role = tagName === "user-query"
        ? "USER"
        : tagName === "model-response"
          ? "AI"
          : "UNKNOWN";
      if (role === "UNKNOWN" || isGeminiDirectRootExcluded(node)) {
        return;
      }

      const text = getGeminiDirectMessageText(node, role);
      if (!text) {
        return;
      }

      messages.push({
        role,
        text,
        source: "gemini-direct-tag"
      });
    });

    return messages;
  }

  function getTopLevelGeminiNodes(nodes) {
    const uniqueNodes = Array.from(new Set(nodes));
    return uniqueNodes.filter(
      (node) => !uniqueNodes.some((other) => other !== node && other.contains(node))
    );
  }

  function isGeminiMessageCandidate(node) {
    if (!node || node.closest("nav, aside, header, footer, form, menu")) {
      return false;
    }
    if (node.querySelector('textarea, input[type="text"], [contenteditable="true"]')) {
      return false;
    }
    const textLength = normalizeText(node.textContent || "").length;
    const richContent = node.querySelector("pre, code-block, table, img, canvas, video, audio");
    return textLength >= 2 && textLength <= 200000 || Boolean(richContent);
  }

  function isGeminiAuxiliaryElement(element) {
    if (!element) {
      return true;
    }
    if (element.matches(GEMINI_EXCLUDED_TEXT_SELECTOR)) {
      return true;
    }
    const auxiliaryParent = element.closest(GEMINI_EXCLUDED_TEXT_SELECTOR);
    return Boolean(auxiliaryParent && auxiliaryParent !== element);
  }

  function getGeminiVisibleText(element) {
    if (!element || isGeminiAuxiliaryElement(element)) {
      return "";
    }

    const visibleText = normalizeText(element.innerText || "");
    const excludedNodes = element.querySelectorAll(GEMINI_EXCLUDED_TEXT_SELECTOR);
    if (excludedNodes.length === 0) {
      return visibleText;
    }

    const clone = element.cloneNode(true);
    clone.querySelectorAll(GEMINI_EXCLUDED_TEXT_SELECTOR).forEach((node) => node.remove());
    return normalizeText(clone.textContent || "");
  }

  function getGeminiTextFromCandidates(root, selectors) {
    if (!root) {
      return "";
    }

    let contentNodes = [];
    for (const selector of selectors) {
      contentNodes = Array.from(root.querySelectorAll(selector))
        .filter((node) => !isGeminiAuxiliaryElement(node));
      if (contentNodes.length > 0) {
        break;
      }
    }

    if (contentNodes.length === 0) {
      const blockNodes = Array.from(root.querySelectorAll(GEMINI_TEXT_BLOCK_SELECTOR))
        .filter((node) => !isGeminiAuxiliaryElement(node));
      contentNodes = blockNodes.filter(
        (node) => !blockNodes.some((other) => other !== node && other.contains(node))
      );
    }

    const seen = new Set();
    return contentNodes
      .map((node) => getGeminiVisibleText(node))
      .filter((text) => {
        if (!text || seen.has(text)) {
          return false;
        }
        seen.add(text);
        return true;
      })
      .join("\n\n");
  }

  function getGeminiResponseContainerText(responseRoot) {
    if (!responseRoot || isGeminiAuxiliaryElement(responseRoot)) {
      return "";
    }

    const structuredContainer = responseRoot.querySelector(
      "structured-content-container > div.container"
    );
    if (structuredContainer) {
      const contentNodes = Array.from(structuredContainer.children || [])
        .filter((node) => ["MESSAGE-CONTENT", "CODE-BLOCK"].includes(node.tagName))
        .filter((node) => !isGeminiAuxiliaryElement(node));
      const contentParts = contentNodes
        .map((node) => getGeminiVisibleText(node))
        .filter(Boolean);
      if (contentParts.length > 0) {
        return contentParts.join("\n\n");
      }
    }

    return getGeminiTextFromCandidates(responseRoot, GEMINI_ASSISTANT_CONTENT_SELECTORS);
  }

  function findGeminiMessagesByConversationContainers() {
    let turns = queryGeminiAll(
      'infinite-scroller[data-test-id="chat-history-container"] .conversation-container'
    );
    if (turns.length === 0) {
      turns = queryGeminiAll("main .conversation-container");
    }

    const messages = [];
    getTopLevelGeminiNodes(turns)
      .filter(isGeminiMessageCandidate)
      .forEach((turn) => {
        const userText = getGeminiTextFromCandidates(turn, GEMINI_USER_CONTENT_SELECTORS);
        if (userText) {
          messages.push({
            role: "USER",
            text: userText,
            source: "gemini-conversation-container"
          });
        }

        let responseRoots = Array.from(turn.querySelectorAll("response-container"));
        if (responseRoots.length === 0) {
          responseRoots = Array.from(turn.querySelectorAll("model-response, .model-response"));
        }
        responseRoots
          .map((responseRoot) => getGeminiResponseContainerText(responseRoot))
          .filter(Boolean)
          .forEach((text) => {
            messages.push({
              role: "AI",
              text,
              source: "gemini-conversation-container"
            });
          });
      });

    return messages;
  }

  function findGeminiMessagesByConversationElements() {
    let nodes = queryGeminiAll(
      "main user-query, main model-response, main .user-query, main .model-response"
    );
    if (nodes.length === 0) {
      nodes = queryGeminiAll(
        'main [data-test-id*="user-query"], main [data-test-id*="model-response"], main [data-testid*="user-query"], main [data-testid*="model-response"]'
      );
    }
    if (nodes.length === 0) {
      nodes = queryGeminiAll("user-query, model-response, .user-query, .model-response");
    }

    nodes = getTopLevelGeminiNodes(nodes).filter(isGeminiMessageCandidate);

    return nodes
      .map((node) => {
        const role = getGeminiRole(node);
        const selectorsForRole = role === "USER"
          ? GEMINI_USER_CONTENT_SELECTORS
          : GEMINI_ASSISTANT_CONTENT_SELECTORS;
        const text = role === "UNKNOWN"
          ? ""
          : getGeminiTextFromCandidates(node, selectorsForRole);
        if (!text) {
          return null;
        }
        return {
          role,
          text,
          source: "gemini-conversation-element"
        };
      })
      .filter(Boolean);
  }

  function findGeminiMessagesByFallbackTurns() {
    const selectors = [
      '[data-test-id="conversation-turn"]',
      '[data-testid="conversation-turn"]',
      '[data-message-author-role]',
      '[class*="conversation-turn"]',
      '[role="listitem"]'
    ];

    for (const selector of selectors) {
      const nodes = getTopLevelGeminiNodes(queryGeminiAll(selector))
        .filter(isGeminiMessageCandidate);
      if (nodes.length === 0) {
        continue;
      }

      const messages = nodes
        .map((node, index) => {
          const detectedRole = getGeminiRole(node);
          const role = detectedRole === "UNKNOWN"
            ? (index % 2 === 0 ? "USER" : "AI")
            : detectedRole;
          const selectorsForRole = role === "USER"
            ? GEMINI_USER_CONTENT_SELECTORS
            : GEMINI_ASSISTANT_CONTENT_SELECTORS;
          const text = getGeminiTextFromCandidates(node, selectorsForRole);
          if (!text) {
            return null;
          }
          return {
            role,
            text,
            source: "gemini-fallback-turn"
          };
        })
        .filter(Boolean);

      if (messages.length > 0) {
        return messages;
      }
    }

    return [];
  }

  function dedupeMessages(messages) {
    const seen = new Set();
    const results = [];

    messages.forEach((message) => {
      const key = `${message.role}:${message.text}`;
      if (!seen.has(key)) {
        seen.add(key);
        results.push(message);
      }
    });

    return results;
  }

  function inferAlternatingRoles(messages) {
    return messages.map((message, index) => {
      if (message.role !== "UNKNOWN") {
        return message;
      }

      return {
        ...message,
        role: index % 2 === 0 ? "USER" : "AI"
      };
    });
  }

  function extractConversation() {
    const provider = getProvider();
    let strategies;
    if (provider === "claude") {
      strategies = [findClaudeMessagesByKnownSelectors, findClaudeMessagesByConversationTurns];
    } else if (provider === "gemini") {
      strategies = [
        findGeminiMessagesByDirectTags,
        findGeminiMessagesByConversationContainers,
        findGeminiMessagesByConversationElements,
        findGeminiMessagesByFallbackTurns
      ];
    } else {
      strategies = [findMessageByDataAttributes, findMessageByArticleElements, findMessageByConversationTurns];
    }

    for (const strategy of strategies) {
      const messages = dedupeMessages(strategy());
      if (
        provider === "gemini" &&
        messages.length > 0 &&
        (!messages.some((message) => message.role === "USER") ||
          !messages.some((message) => message.role === "AI"))
      ) {
        continue;
      }
      if (messages.length > 0) {
        return inferAlternatingRoles(messages);
      }
    }

    return [];
  }

  function getSelectionText() {
    return normalizeText(window.getSelection()?.toString() || "");
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message || !["EXTRACT_AI_LOG", "EXTRACT_CHATGPT_LOG"].includes(message.type)) {
      return false;
    }

    try {
      const provider = getProvider();
      const messages = extractConversation();
      if (!messages.length) {
        sendResponse({
          ok: false,
          error: chrome.i18n.getMessage("conversationNotFound")
        });
        return true;
      }

      sendResponse({
        ok: true,
        provider,
        title: document.title
          .replace(/\s*[-|]\s*(ChatGPT|Claude|Gemini)\s*$/i, "")
          .trim() || (
            provider === "claude"
              ? "Claude Conversation"
              : provider === "gemini"
                ? "Gemini Conversation"
                : "ChatGPT Conversation"
          ),
        url: location.href,
        selectionText: getSelectionText(),
        messages
      });
    } catch (error) {
      sendResponse({
        ok: false,
        error: error.message || chrome.i18n.getMessage("extractionFailed")
      });
    }

    return true;
  });
})();
